public class InvalidMenuChoiceException extends Exception {
    public InvalidMenuChoiceException(String message) {
        super(message);
    }
}
